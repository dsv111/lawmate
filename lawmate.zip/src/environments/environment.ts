export const environment = {
  production: false,
  // geminiApiKey: 'AIzaSyD4VP1f8OEWzm0-6tQbGOkgLoxbla1KKKs', // **DO NOT COMMIT THIS TO GIT FOR PROD KEYS!**
  geminiApiKey: 'AIzaSyC55CdCA72hyy8OSVIcN6LCOG6oA0HLHpY', // **DO NOT COMMIT THIS TO GIT FOR PROD KEYS!**

};