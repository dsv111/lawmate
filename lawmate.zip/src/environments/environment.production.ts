export const environment = {
  production: true,
  geminiApiKey: 'AIzaSyBGdxAAW6TVQmHjlK-E-gnoc_zGgvOWbIw', // **DANGER: This will be in your compiled JS!**
};